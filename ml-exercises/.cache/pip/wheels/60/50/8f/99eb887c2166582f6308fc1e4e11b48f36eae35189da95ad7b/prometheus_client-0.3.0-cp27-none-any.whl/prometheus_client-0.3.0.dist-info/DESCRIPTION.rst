See https://github.com/prometheus/client_python/blob/master/README.md for documentation.


